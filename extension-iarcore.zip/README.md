# extension-iarcore
A Haxe/Lime extension that implements In-App Reviews (IAR) functionality for Android devices.
